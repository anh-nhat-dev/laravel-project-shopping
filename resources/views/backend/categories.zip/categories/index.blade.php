@extends('layout.backend.master')

@section('title', 'Danh sách danh mục')

@section('main')
<div class="row bg-title">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <h4 class="page-title">List Categories </h4>
    </div>
    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
        <ol class="breadcrumb">
            <li><a href="{{route('admin.dashboard')}}">Dashboard</a></li>
            <li class="active">List Categories</li>
        </ol>
    </div>

</div>
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default block1">
            <div class="panel-heading">
                <a href="http://localhost:8000/admin/categories/add" class="btn btn-success" id="unblockbtn1"><i class="icon-plus"></i>
                    Create</a>
            </div>
            <div class="panel-wrapper collapse in">
                <div class="panel-body">
                    <div class="table-responsive">
                        <table id="example23" class="display nowrap" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Categories name</th>
                                    <th>Update</th>
                                    <th>Create</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>#1</td>
                                    <td>Danh mục số 1</td>
                                    <td>10-12-2018</td>
                                    <td>10-12-2018</td>
                                    <td><span class="label label-success label-rounded">ACTIVE</span></td>
                                    <td>
                                        <a href="http://localhost:8000/admin/categories/1/edit" class="btn btn-info "><i
                                                class="icon-pencil"></i>
                                        </a>
                                        <a href="http://localhost:8000/admin/categories/1/delete" class="btn btn-danger"><i
                                                class="icon-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>#4</td>
                                    <td>Danh mục số 4</td>
                                    <td>10-12-2018</td>
                                    <td>10-12-2018</td>
                                    <td><span class="label label-success label-rounded">ACTIVE</span></td>
                                    <td>
                                        <a href="http://localhost:8000/admin/categories/4/edit" class="btn btn-info "><i
                                                class="icon-pencil"></i>
                                        </a>
                                        <a href="http://localhost:8000/admin/categories/4/delete" class="btn btn-danger"><i
                                                class="icon-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>#2</td>
                                    <td>--Danh mục con số 1</td>
                                    <td>10-12-2018</td>
                                    <td>10-12-2018</td>
                                    <td><span class="label label-success label-rounded">ACTIVE</span></td>
                                    <td>
                                        <a href="http://localhost:8000/admin/categories/2/edit" class="btn btn-info "><i
                                                class="icon-pencil"></i>
                                        </a>
                                        <a href="http://localhost:8000/admin/categories/2/delete" class="btn btn-danger"><i
                                                class="icon-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>#3</td>
                                    <td>--Danh mục số 2</td>
                                    <td>10-12-2018</td>
                                    <td>10-12-2018</td>
                                    <td><span class="label label-success label-rounded">ACTIVE</span></td>
                                    <td>
                                        <a href="http://localhost:8000/admin/categories/3/edit" class="btn btn-info "><i
                                                class="icon-pencil"></i>
                                        </a>
                                        <a href="http://localhost:8000/admin/categories/3/delete" class="btn btn-danger"><i
                                                class="icon-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
@stop

@section('script')
<script>
    $(document).ready(function () {
        $('#example23').DataTable({
            dom: 'Bfrtip',
            buttons: [
               
            ],
            bSort: false
        });
    })
</script>
@stop